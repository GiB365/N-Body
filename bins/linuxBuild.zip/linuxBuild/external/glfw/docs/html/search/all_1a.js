var searchData=
[
  ['x11_0',['Dependencies for Wayland and X11',['../compile_guide.html#compile_deps_wayland',1,'']]],
  ['x11_20extensions_20protocols_20and_20ipc_20standards_1',['X11 extensions, protocols and IPC standards',['../compat_guide.html#compat_x11',1,'']]],
  ['x11_20specific_20init_20hints_2',['X11 specific init hints',['../intro_guide.html#init_hints_x11',1,'']]],
  ['x11_20specific_20window_20hints_3',['X11 specific window hints',['../window_guide.html#window_hints_x11',1,'']]],
  ['xcode_20on_20macos_4',['With Xcode on macOS',['../build_guide.html#build_link_xcode',1,'']]],
  ['xp_5',['Support for versions of Windows older than XP',['../moving_guide.html#moving_windows',1,'']]],
  ['xp_20and_20vista_20support_20has_20been_20removed_6',['Windows XP and Vista support has been removed',['../news.html#winxp_vista',1,'']]]
];
