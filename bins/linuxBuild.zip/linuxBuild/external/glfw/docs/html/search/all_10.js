var searchData=
[
  ['name_0',['name',['../monitor_guide.html#monitor_name',1,'Human-readable name'],['../input_guide.html#joystick_name',1,'Joystick name']]],
  ['name_20change_20tables_1',['Name change tables',['../moving_guide.html#moving_tables',1,'']]],
  ['names_2',['Key names',['../input_guide.html#input_key_name',1,'']]],
  ['native_20access_3',['Native access',['../group__native.html',1,'']]],
  ['native_20access_20function_4',['native access function',['../news.html#eglconfig',1,'EGLConfig native access function'],['../news.html#glxfbconfig',1,'GLXFBConfig native access function']]],
  ['native_20interface_5',['Native interface',['../internals_guide.html#internals_native',1,'']]],
  ['new_20constants_6',['New constants',['../news.html#new_constants',1,'']]],
  ['new_20features_7',['New features',['../news.html#features',1,'']]],
  ['new_20functions_8',['New functions',['../news.html#new_functions',1,'']]],
  ['new_20symbols_9',['New symbols',['../news.html#new_symbols',1,'']]],
  ['new_20types_10',['New types',['../news.html#new_types',1,'']]],
  ['news_2emd_11',['news.md',['../news_8md.html',1,'']]],
  ['notes_20for_20earlier_20versions_12',['Release notes for earlier versions',['../news.html#news_archive',1,'']]],
  ['notes_20for_20version_203_205_13',['Release notes for version 3.5',['../news.html',1,'']]]
];
