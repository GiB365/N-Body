var searchData=
[
  ['user_0',['user',['../structGLFWallocator.html#af6153be74dbaf7f0a7e8bd3bfc039910',1,'GLFWallocator']]]
];
