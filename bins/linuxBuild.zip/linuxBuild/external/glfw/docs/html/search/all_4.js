var searchData=
[
  ['been_20removed_0',['been removed',['../news.html#original_mingw',1,'Original MinGW support has been removed'],['../news.html#winxp_vista',1,'Windows XP and Vista support has been removed']]],
  ['binaries_1',['binaries',['../build_guide.html#build_link_cmake_package',1,'With CMake and installed GLFW binaries'],['../build_guide.html#build_link_mingw',1,'With MinGW-w64 and GLFW binaries'],['../build_guide.html#build_link_win32',1,'With Visual C++ and GLFW binaries']]],
  ['binaries_20on_20unix_2',['With pkg-config and GLFW binaries on Unix',['../build_guide.html#build_link_pkgconfig',1,'']]],
  ['blue_3',['blue',['../structGLFWgammaramp.html#acf0c836d0efe29c392fe8d1a1042744b',1,'GLFWgammaramp']]],
  ['bluebits_4',['blueBits',['../structGLFWvidmode.html#af310977f58d2e3b188175b6e3d314047',1,'GLFWvidmode']]],
  ['buffer_20swapping_5',['buffer swapping',['../window_guide.html#buffer_swap',1,'Buffer swapping'],['../context_guide.html#context_swap',1,'Buffer swapping']]],
  ['buffers_6',['Swapping buffers',['../quick_guide.html#quick_swap_buffers',1,'']]],
  ['build_20files_20with_20cmake_7',['Generating build files with CMake',['../compile_guide.html#compile_generate',1,'']]],
  ['build_2emd_8',['build.md',['../build_8md.html',1,'']]],
  ['building_20applications_9',['Building applications',['../build_guide.html',1,'']]],
  ['button_20input_10',['Mouse button input',['../input_guide.html#input_mouse_button',1,'']]],
  ['button_20states_11',['Joystick button states',['../input_guide.html#joystick_button',1,'']]],
  ['buttons_12',['buttons',['../structGLFWgamepadstate.html#a27e9896b51c65df15fba2c7139bfdb9a',1,'GLFWgamepadstate::buttons'],['../group__gamepad__buttons.html',1,'Gamepad buttons'],['../group__buttons.html',1,'Mouse buttons'],['../news.html#unlimited_mouse_buttons',1,'Unlimited mouse buttons']]],
  ['by_20scroll_20offsets_13',['Wheel position replaced by scroll offsets',['../moving_guide.html#moving_wheel',1,'']]],
  ['by_20step_14',['Step by step',['../quick_guide.html#quick_steps',1,'']]]
];
